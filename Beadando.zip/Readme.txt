Félévi projekt leadása levelezős hallgatók részére

Két fájlt töltsenek fel.

- A projektjüket tömörítsék be, de előtt az Android Studion belül a Build menüben válasszák a Clean Project menüpontot. (Generált fájlok törlésre kerülnek és így kisebb lesz a projekt.)
- Funkciók_listája.xlsx amit töltsenek is ki. (Válasszák ki melyik funkciókat valósították meg a projektben.)


Megvalósítás:

- Fragmentek külön elérhetőek a felső menüsoron. ViewModel átadás a fragmenteknél az Editbox és a gomb használtalával.
- Új jegyzetek felvétele a "+" gombal.
- Jegyzet törlése a tétel balra vagy jobbra húzásával, vagy a fenti menüsorból (Összes jegyzet törlése).
- Jegyzet módosítása a jegyzetre koppintva.
- JobIntentService megvalósítása a Fragment osztályal együtemben.
- JobIntent megjelenítése a Fragment ablakon
- On_START és ON_Stop megvalósítás a Fragment osztályban.
